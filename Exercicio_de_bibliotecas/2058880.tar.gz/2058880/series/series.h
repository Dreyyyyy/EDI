#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int sequencia_pow(int n);

int sequencia_alternando(int a);
