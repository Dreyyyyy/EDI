#include <stdio.h>
#include <stdlib.h>

int multiplicacao_naturais(int a, int b);

int fatorial(int a);

int divisao(int a, int b);
